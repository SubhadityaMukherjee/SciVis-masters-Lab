#ifndef CONSTANTS_H
#define CONSTANTS_H

namespace constants
{
    // Mathematical constants
    float const pi = 3.1415927410125732F;
}

#endif // CONSTANTS_H
