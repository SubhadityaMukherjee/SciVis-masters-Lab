#ifndef LEGENDSCALARDATA_H
#define LEGENDSCALARDATA_H

#include "legend.h"

class LegendScalarData : public Legend
{
public:
    using Legend::Legend;
};

#endif // LEGENDSCALARDATA_H
